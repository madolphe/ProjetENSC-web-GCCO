<?php
session_start();
$_SESSION["page"]="index";
include_once "header.php";
?>

<?php include_once  "footer.php"?>

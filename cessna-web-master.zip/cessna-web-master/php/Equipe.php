
<?php session_start();
$_SESSION["page"]="index";
include_once "header.php"; ?>
<div class="container equipe">
	<div class="row">
		<div class="col-3 text-center">
			<div class="card mb-3">
				<h3 class="card-header">Lylia <br> Fauvel</h3>
				<div class="card-body">
					<h5 class="card-title">"L'atout BDA du groupe."</h5>
				</div>
				<img style="height: 200px; width: 100%; display: block;" src="../images/Lylou.png" alt="Card image">
				<div class="card-body">
					<p class="card-text">Formation</p>
				</div>
				<ul class="list-group list-group-flush">
					<li class="list-group-item">Cras justo odio</li>
					<li class="list-group-item">Dapibus ac facilisis in</li>
					<li class="list-group-item">Vestibulum at eros</li>
				</ul>
				<div class="card-footer text-muted">
					2 days ago
				</div>
			</div>
		</div>
		<div class="col-3 text-center"> 	<div class="card mb-3">
				<h3 class="card-header">Raphael Chirac</h3>
				<div class="card-body">
					<h5 class="card-title">"Trés doué en simulation, pourtant c'est un rugbyman?"</h5>
				</div>
				<img style="height: 200px; width: 100%; display: block;" src="../images/Raphou.png" alt="Card image">
				<div class="card-body">
					<p class="card-text">Formation</p>
				</div>
				<ul class="list-group list-group-flush">
					<li class="list-group-item">Cras justo odio</li>
					<li class="list-group-item">Dapibus ac facilisis in</li>
					<li class="list-group-item">Vestibulum at eros</li>
				</ul>
				<div class="card-footer text-muted">
					2 days ago
				</div>
			</div>
 </div>
		<div class="col-3 text-center"> 	<div class="card mb-3">
				<h3 class="card-header">Debenay Valentin</h3>
				<div class="card-body">
					<h5 class="card-title">"Manie ses doigts comme personne, et je ne parle pas de jeux vidéos"</h5>
				</div>
				<img style="height: 200px; width: 100%; display: block;" src="../images/Valou.png" alt="Card image">
				<div class="card-body">
					<p class="card-text">Formation</p>
				</div>
				<ul class="list-group list-group-flush">
					<li class="list-group-item">Cras justo odio</li>
					<li class="list-group-item">Dapibus ac facilisis in</li>
					<li class="list-group-item">Vestibulum at eros</li>
				</ul>
				<div class="card-footer text-muted">
					2 days ago
				</div>
			</div>
		 </div>
		<div class="col-3 text-center"> 	<div class="card mb-3">
				<h3 class="card-header">Adolphe Maxime</h3>
				<div class="card-body">
					<h5 class="card-title">"Travaille beacoup trop bien."</h5>
				</div>
				<img style="height: 200px; width: 100%; display: block;" src="../images/max.png" alt="Card image">
				<div class="card-body">
					<p class="card-text">Role</p>
				</div>
				<ul class="list-group list-group-flush">
					<li class="list-group-item">Formation :
                    Bac S - Prépa MP</li>
					<li class="list-group-item">Compétences:
                    Bogossitude <br> Sait souder 2 fils mais parfois ca foire <br> Aime le contact humain </li>
				</ul>
			</div>
 </div>
	</div>
</div>
<br><br>
<?php include_once "footer.php" ?>

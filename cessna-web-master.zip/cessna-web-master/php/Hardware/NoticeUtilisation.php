<?php
session_start();
$_SESSION["page"]="hardware";
include_once "../header.php";
?>

<?php include_once "../footer.php"; ?>
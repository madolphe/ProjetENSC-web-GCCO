<?php
session_start();
$_SESSION['page']="software";
include_once "../header.php";
?>
<?php include_once "../footer.php"; ?>

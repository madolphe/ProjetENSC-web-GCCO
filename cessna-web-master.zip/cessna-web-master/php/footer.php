<div class="container-fluid footer">
    <div class="row textFooter">
        <div class="col-3 text-center"><a href="Equipe.php">Qui sommes-nous? </a></div>
        <div class="col-3 text-center"><a href="#">Nous contacter</a></div>
        <div class="col-3 text-center"><a href="#">ENSC</a></div>
        <div class="col-3 text-center"><img src=""></div>
    </div>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</html>
